﻿using Server_Side_408;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ClientApp2
{
    public partial class Form1 : Form
    {
        bool terminating = false;
        bool connected = false;
        bool IFsub = false;
        bool SPSsub = false;
        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            handleChatClick(0);
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = textBox_ip.Text;
            string username = textBox_name.Text.Trim();


            int portNum;


            if (Int32.TryParse(textBox_port.Text, out portNum))
            {
                try
                {
                    clientSocket.Connect(IP, portNum);
                    button_connect.Enabled = false;
                    button_SPSsend.Enabled = true;
                    button_IFsend.Enabled = true;


                    //introduce yourself
                    string message = username + " " + "-A    ";
                    //ClientRequest request = new ClientRequest("username", "request-type", "channel", "body");
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }

                    //response from server about connection
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);
                    
                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    //log.AppendText(responseString);
               
                    if (response.ResponseCode == "204")
                    {
                        //successful connection, can subscr to channels
                        log.AppendText("Server: " + responseString + "\n");
                        connected = true;
                        button_disconnect.Enabled = true;
                        button_subIF100.Enabled = true;
                        button_subSPS101.Enabled = true;
                        Thread receiveThread = new Thread(Receive);
                        receiveThread.Start();
                    }
                    else
                    {
                        log.AppendText("Server: Connection Failed\n");
                        button_connect.Enabled = true;
                    }

                }
                catch
                {
                    log.AppendText("Could not connect to the server!\n");
                }
                
            }
            else
            {
                log.AppendText("Check the port\n");
            }

        }
        private void Receive()
        {
            while(connected)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    //chat_logs_if100.AppendText(" received\n");

                    Byte[] buffer = new Byte[64];
                    clientSocket.Receive(buffer);
                    //chat_logs_if100.AppendText(" received\n");

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    ServerResponse response = new ServerResponse(incomingMessage);
                    switch(response.ResponseCode)
                    {
                        case "198":
                            if (response.Channel == "0")
                            {
                                chat_logs_if100.AppendText(response.Username + ":\n" + response.Body + "\n");
                            }
                            else if (response.Channel == "1")
                            {
                                chat_logs_sps101.AppendText(response.Username + ":\n" + response.Body + "\n");
                            }
                            break;
                        case "200":
                            //chat_logs_if100.AppendText(response.Username + ":\n" + response.Body + "\n");
                            //log.AppendText($"Message Sent Succesfully");
                            break;
                        case "201":
                            if(response.Channel == "0" && IFsub == false)
                            {
                                IFsub = true;
                                log.AppendText($"Subscribed");
                            }
                            else if (response.Channel == "0" && IFsub == true)
                            {
                                IFsub = false;
                                log.AppendText($"Unsubscribed");
                            }
                            else if (response.Channel == "1" && SPSsub == false)
                            {
                                SPSsub = true;
                                log.AppendText($"Subscribed");
                            }
                            else if (response.Channel == "1" && SPSsub == true)
                            {
                                SPSsub = false;
                                log.AppendText($"Unsubscribed");
                            }
                            else
                            {
                                log.AppendText($"Can't Subscribe/Unsubcribe");
                            }
                            log.AppendText($" to channel: {response.Channel}\n");
                            break;
                        case "202":
                            DisconnectClient();
                            try
                            {
                                clientSocket.Close();
                            }
                            catch (Exception ex)
                            {
                                // Handle exceptions related to cleanup tasks if necessary
                                log.AppendText("Exception during disconnection: " + ex.Message + "\n");
                                terminating = true;
                                Environment.Exit(0);
                            }
                            log.AppendText("Disconnected Successfully\n");
                            break;
                        case "204":
                            break;
                        case "400":
                            log.AppendText($"Bad request.\n");
                            break;
                        case "403":
                            log.AppendText($"You are not subscribed to the corresponding channel. Unauthorized request\n");
                            break;
                        case "500":
                            log.AppendText($"Something's wrong with the server. Internal Server Error\n");
                            break;
                    }

                    //log.AppendText("Server: " + incomingMessage + "\n");
                }
                catch
                {
                    if (!terminating)
                    {
                        log.AppendText("The server has disconnected\n");
                        button_connect.Enabled = true;
                        //textBox_message.Enabled = false;
                        //button_send.Enabled = false;
                    }

                    clientSocket.Close();
                    connected = false;
                }

            }
        }

        private void button_subIF100_Click(object sender, EventArgs e)
        {
            if (connected)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    //button_subIF100.Enabled = false; 
                    //subscr req
                    string message = username + " " + "-S " + "0  ";
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }

                    /*
                    //response from server about subscr
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);


                    if (response.ResponseCode == "201")
                    {
                        //successful connection, can subscr to channels
                        log.AppendText("Server: " + responseString + "\n");
                        log.AppendText("You subscribed to IF 100!\n");
                        IFsub = true;
                        button_IFsend.Enabled = true;
                        button_unsubIF100.Enabled = true;

                    }
                    else
                    {
                        log.AppendText("Server: Subscription Failed\n");
                        button_subIF100.Enabled = true;
                    }
                    */
                }
                catch
                {
                    log.AppendText("Could not subscribe to IF 100 channel!\n");
                }
            }
        }

        private void button_IFsend_Click(object sender, EventArgs e)
        {
            if (IFsub)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                   
                    //subscr req
                    string message = username + " -M 0 " + textBox_IF.Text.Trim();
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }
                    /*
                    //response from server about connection
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);                 

                     if (response.ResponseCode == "200")
                    {
                        //successful connection, can subscr to channels
                        //log.AppendText("Server: " + responseString + "\n");
                        //log.AppendText("You send a msg to IF 100!\n");
                        chat_logs_if100.AppendText(response.Username + ":\n" + response.Body + "\n");

                    }
                    else
                    {
                        log.AppendText("Server: Could not send your message to IF 100!\n");
                    }
                    */
                }
                catch
                {
                    log.AppendText("Could not send your message to IF 100!\n");
                }
            }
            else
            {
                log.AppendText("You are not subscribed to the corresponding channel\n");
            }
        }
        /*
        private void button_unsubIF100_Click(object sender, EventArgs e)
        {
            if(IFsub)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    button_unsubIF100.Enabled = false;

                    //unsubscr request
                    string message = username + " " + "-S " + "0  ";
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }

                    /*
                    //response from server about subscr
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);

                    if(response.ResponseCode == "200")
                    {
                        //sucessful unsub from channel
                        log.AppendText("You unsubscribed from IF 100!\n");
                        IFsub = false;
                        button_subIF100.Enabled = true;
                        button_IFsend.Enabled = false;
                        //also can not receive msg from channel 100

                    }
                    else
                    {
                        log.AppendText("Server: Unsubscription Failed\n");
                        button_unsubIF100.Enabled = true;
                    }
                    // There should be a -> * /
                }
                catch
                {
                    log.AppendText("Could not unsubscribe from IF 100 channel!\n");
                }
            }              
        }

*/
        private void button_subSPS101_Click(object sender, EventArgs e)
        {
            if (connected)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    //button_subSPS101.Enabled = false; 
                    //subscr req
                    string message = username + " " + "-S " + "1  ";
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }

                    /*
                    //response from server about subscr
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);


                    if (response.ResponseCode == "201")
                    {
                        //successful connection, can subscr to channels
                        log.AppendText("Server: " + responseString + "\n");
                        log.AppendText("You subscribed to SPS101!\n");
                        SPSsub = true;
                        button_SPSsend.Enabled = true;
                        button_unsubSPS101.Enabled = true;

                    }
                    else
                    {
                        log.AppendText("Server: Subscription Failed\n");
                        button_subSPS101.Enabled = true;
                    }*/

                }
                catch
                {
                    log.AppendText("Could not subscribe to SPS 101 channel!\n");
                }
            }
        }

        private void button_SPSsend_Click(object sender, EventArgs e)
        {
            if (SPSsub)
            {
                string username = textBox_name.Text.Trim();
                try
                {

                    //subscr req
                    string message = username + " -M 1 " + textBox_SPS.Text.Trim();
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }
                    /*
                    //response from server about connection
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);

                    if (response.ResponseCode == "200")
                    {
                        //successful connection, can subscr to channels
                        //log.AppendText("Server: " + responseString + "\n");
                        chat_logs_sps101.AppendText(response.Username + ":\n" + response.Body + "\n");
                        //log.AppendText("You send a msg to SPS 101!\n");

                    }
                    else
                    {
                        log.AppendText("Server: Could not send your message to SPS 101!\n");
                    }*/

                }
                catch
                {
                    log.AppendText("Could not send your message to SPS 101!\n");
                }
            }
        }
        /*
        private void button_unsubSPS101_Click(object sender, EventArgs e)
        {
            if (SPSsub)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    //button_unsubSPS101.Enabled = false;

                    //unsubscr request
                    string message = username + " " + "-S " + "1  ";
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }


                    //response from server about subscr
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);

                    if (response.ResponseCode == "201")
                    {
                        //sucessful unsub from channel
                        log.AppendText("You unsubscribed from SPS 101!\n");
                        SPSsub = false;
                        button_subSPS101.Enabled = true;
                        button_SPSsend.Enabled = false;
                        //also can not receive msg from channel 100

                    }
                    else
                    {
                        log.AppendText("Server: Unsubscription Failed\n");
                        //button_unsubSPS101.Enabled = true;
                    }
                }
                catch
                {
                    log.AppendText("Could not unsubscribe from SPS 101 channel!\n");
                }
            }
        }
        */
        private void button_disconnect_Click(object sender, EventArgs e)
        {
           if(connected)
            {
                string username = textBox_name.Text.Trim();
                try
                {
                    //disconnection req to server
                    string message = username + " " + "-D    ";
                    //ClientRequest request = new ClientRequest("username", "request-type", "channel", "body");
                    if (message != "" && message.Length <= 64)
                    {
                        Byte[] buffer = Encoding.Default.GetBytes(message);
                        clientSocket.Send(buffer);
                    }

                    /*
                    //response from server about connection
                    Byte[] responseBuffer = new Byte[64];
                    clientSocket.Receive(responseBuffer);

                    string responseString = Encoding.Default.GetString(responseBuffer);
                    responseString = responseString.Substring(0, responseString.IndexOf("\0"));

                    ServerResponse response = new ServerResponse(responseString);
                    log.AppendText(responseString);

                    if (response.ResponseCode == "200")
                    {
                        DisconnectClient();
                        try
                        {
                            clientSocket.Close();
                        }
                        catch (Exception ex)
                        {
                            // Handle exceptions related to cleanup tasks if necessary
                            log.AppendText("Exception during disconnection: " + ex.Message + "\n");
                            terminating = true;
                            Environment.Exit(0);
                        }
                        log.AppendText("Disconnected from server!");

                    }
                    else
                    {
                        log.AppendText("Disconnection failed: " + responseString + "\n");
                    }
                    */
                }
                catch
                {
                    log.AppendText("Exception during disconnection!\n");
                }
            }
            
        }

        private void DisconnectClient()
        {
            connected = false;
            button_connect.Enabled = true; // Enable the connect button again
            //disable all other buttons
            button_IFsend.Enabled = false;
            button_SPSsend.Enabled = false;
            button_subIF100.Enabled = false;
            button_subSPS101.Enabled = false;
            //button_unsubIF100.Enabled = false;
            //button_unsubSPS101.Enabled = false;
            button_disconnect.Enabled = false;
            IFsub = false;
            SPSsub = false;
            

        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if(connected)
            {
                DisconnectClient();
                try
                {
                    clientSocket.Close();
                }
                catch (Exception ex)
                {
                    // Handle exceptions related to cleanup tasks if necessary
                    log.AppendText("Exception during disconnection: " + ex.Message + "\n");
                }
            }
            
            terminating = true;
            Environment.Exit(0);
        }

        private void chat_if_button_Click(object sender, EventArgs e)
        {
            handleChatClick(0);
        }

        private void chat_sps_button_Click(object sender, EventArgs e)
        {
            handleChatClick(1);
        }

        private void handleChatClick(int channel)
        {
            if(channel == 0)
            {
                chat_logs_if100.Visible = true;
                chat_logs_sps101.Visible = false;
                chat_if_button.Enabled = false;
                chat_sps_button.Enabled = true;
            }
            else
            {
                chat_logs_sps101.Visible = true;
                chat_logs_if100.Visible = false;
                chat_if_button.Enabled = true;
                chat_sps_button.Enabled = false;
            }
        }
    }
}
