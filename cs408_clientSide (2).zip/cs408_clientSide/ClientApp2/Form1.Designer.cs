﻿namespace ClientApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_ip = new System.Windows.Forms.TextBox();
            this.textBox_port = new System.Windows.Forms.TextBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.button_connect = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button_subIF100 = new System.Windows.Forms.Button();
            this.textBox_IF = new System.Windows.Forms.TextBox();
            this.button_IFsend = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button_subSPS101 = new System.Windows.Forms.Button();
            this.textBox_SPS = new System.Windows.Forms.TextBox();
            this.button_SPSsend = new System.Windows.Forms.Button();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.chat_logs_if100 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chat_logs_sps101 = new System.Windows.Forms.RichTextBox();
            this.chat_if_button = new System.Windows.Forms.Button();
            this.chat_sps_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 98);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 165);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Port:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(123, 238);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Username:";
            // 
            // textBox_ip
            // 
            this.textBox_ip.Location = new System.Drawing.Point(236, 86);
            this.textBox_ip.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_ip.Name = "textBox_ip";
            this.textBox_ip.Size = new System.Drawing.Size(148, 26);
            this.textBox_ip.TabIndex = 3;
            // 
            // textBox_port
            // 
            this.textBox_port.Location = new System.Drawing.Point(236, 158);
            this.textBox_port.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_port.Name = "textBox_port";
            this.textBox_port.Size = new System.Drawing.Size(148, 26);
            this.textBox_port.TabIndex = 4;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(236, 238);
            this.textBox_name.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(148, 26);
            this.textBox_name.TabIndex = 5;
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(236, 295);
            this.button_connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(112, 35);
            this.button_connect.TabIndex = 6;
            this.button_connect.Text = "Connect";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // log
            // 
            this.log.Location = new System.Drawing.Point(1192, 368);
            this.log.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(433, 470);
            this.log.TabIndex = 7;
            this.log.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(123, 375);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "IF 100:";
            // 
            // button_subIF100
            // 
            this.button_subIF100.Enabled = false;
            this.button_subIF100.Location = new System.Drawing.Point(236, 368);
            this.button_subIF100.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_subIF100.Name = "button_subIF100";
            this.button_subIF100.Size = new System.Drawing.Size(112, 35);
            this.button_subIF100.TabIndex = 9;
            this.button_subIF100.Text = "subscr";
            this.button_subIF100.UseVisualStyleBackColor = true;
            this.button_subIF100.Click += new System.EventHandler(this.button_subIF100_Click);
            // 
            // textBox_IF
            // 
            this.textBox_IF.Location = new System.Drawing.Point(236, 438);
            this.textBox_IF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_IF.Name = "textBox_IF";
            this.textBox_IF.Size = new System.Drawing.Size(232, 26);
            this.textBox_IF.TabIndex = 11;
            // 
            // button_IFsend
            // 
            this.button_IFsend.Enabled = false;
            this.button_IFsend.Location = new System.Drawing.Point(357, 478);
            this.button_IFsend.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_IFsend.Name = "button_IFsend";
            this.button_IFsend.Size = new System.Drawing.Size(112, 34);
            this.button_IFsend.TabIndex = 12;
            this.button_IFsend.Text = "send";
            this.button_IFsend.UseVisualStyleBackColor = true;
            this.button_IFsend.Click += new System.EventHandler(this.button_IFsend_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(128, 545);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "SPS 101";
            // 
            // button_subSPS101
            // 
            this.button_subSPS101.Enabled = false;
            this.button_subSPS101.Location = new System.Drawing.Point(236, 529);
            this.button_subSPS101.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_subSPS101.Name = "button_subSPS101";
            this.button_subSPS101.Size = new System.Drawing.Size(112, 35);
            this.button_subSPS101.TabIndex = 14;
            this.button_subSPS101.Text = "subscr";
            this.button_subSPS101.UseVisualStyleBackColor = true;
            this.button_subSPS101.Click += new System.EventHandler(this.button_subSPS101_Click);
            // 
            // textBox_SPS
            // 
            this.textBox_SPS.Location = new System.Drawing.Point(236, 592);
            this.textBox_SPS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_SPS.Name = "textBox_SPS";
            this.textBox_SPS.Size = new System.Drawing.Size(232, 26);
            this.textBox_SPS.TabIndex = 16;
            // 
            // button_SPSsend
            // 
            this.button_SPSsend.Enabled = false;
            this.button_SPSsend.Location = new System.Drawing.Point(357, 632);
            this.button_SPSsend.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_SPSsend.Name = "button_SPSsend";
            this.button_SPSsend.Size = new System.Drawing.Size(112, 35);
            this.button_SPSsend.TabIndex = 17;
            this.button_SPSsend.Text = "send";
            this.button_SPSsend.UseVisualStyleBackColor = true;
            this.button_SPSsend.Click += new System.EventHandler(this.button_SPSsend_Click);
            // 
            // button_disconnect
            // 
            this.button_disconnect.Enabled = false;
            this.button_disconnect.Location = new System.Drawing.Point(357, 295);
            this.button_disconnect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(112, 35);
            this.button_disconnect.TabIndex = 18;
            this.button_disconnect.Text = "Disconnect";
            this.button_disconnect.UseVisualStyleBackColor = true;
            this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
            // 
            // chat_logs_if100
            // 
            this.chat_logs_if100.Location = new System.Drawing.Point(635, 368);
            this.chat_logs_if100.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chat_logs_if100.Name = "chat_logs_if100";
            this.chat_logs_if100.Size = new System.Drawing.Size(433, 470);
            this.chat_logs_if100.TabIndex = 19;
            this.chat_logs_if100.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(635, 309);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Chat";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1198, 302);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 20);
            this.label7.TabIndex = 21;
            this.label7.Text = "Logs";
            // 
            // chat_logs_sps101
            // 
            this.chat_logs_sps101.Location = new System.Drawing.Point(635, 368);
            this.chat_logs_sps101.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chat_logs_sps101.Name = "chat_logs_sps101";
            this.chat_logs_sps101.Size = new System.Drawing.Size(433, 470);
            this.chat_logs_sps101.TabIndex = 22;
            this.chat_logs_sps101.Text = "";
            // 
            // chat_if_button
            // 
            this.chat_if_button.Location = new System.Drawing.Point(743, 309);
            this.chat_if_button.Name = "chat_if_button";
            this.chat_if_button.Size = new System.Drawing.Size(100, 35);
            this.chat_if_button.TabIndex = 23;
            this.chat_if_button.Text = "IF100";
            this.chat_if_button.UseVisualStyleBackColor = true;
            this.chat_if_button.Click += new System.EventHandler(this.chat_if_button_Click);
            // 
            // chat_sps_button
            // 
            this.chat_sps_button.Location = new System.Drawing.Point(866, 309);
            this.chat_sps_button.Name = "chat_sps_button";
            this.chat_sps_button.Size = new System.Drawing.Size(104, 35);
            this.chat_sps_button.TabIndex = 24;
            this.chat_sps_button.Text = "SPS101";
            this.chat_sps_button.UseVisualStyleBackColor = true;
            this.chat_sps_button.Click += new System.EventHandler(this.chat_sps_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1638, 919);
            this.Controls.Add(this.chat_sps_button);
            this.Controls.Add(this.chat_if_button);
            this.Controls.Add(this.chat_logs_sps101);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.chat_logs_if100);
            this.Controls.Add(this.button_disconnect);
            this.Controls.Add(this.button_SPSsend);
            this.Controls.Add(this.textBox_SPS);
            this.Controls.Add(this.button_subSPS101);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_IFsend);
            this.Controls.Add(this.textBox_IF);
            this.Controls.Add(this.button_subIF100);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.log);
            this.Controls.Add(this.button_connect);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.textBox_port);
            this.Controls.Add(this.textBox_ip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_ip;
        private System.Windows.Forms.TextBox textBox_port;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.RichTextBox log;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_subIF100;
        private System.Windows.Forms.TextBox textBox_IF;
        private System.Windows.Forms.Button button_IFsend;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_subSPS101;
        private System.Windows.Forms.TextBox textBox_SPS;
        private System.Windows.Forms.Button button_SPSsend;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.RichTextBox chat_logs_if100;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox chat_logs_sps101;
        private System.Windows.Forms.Button chat_if_button;
        private System.Windows.Forms.Button chat_sps_button;
    }
}

