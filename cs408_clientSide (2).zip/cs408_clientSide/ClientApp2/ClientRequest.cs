﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server_Side_408
{
    class ClientRequest
    {
        public string Username { get; set; }
        public string RequestType { get; set; }
        public string Channel { get; set; }
        public string Body { get; set; }

        public ClientRequest(String message)
        {
            string[] parts = message.Split(new char[] { ' ' }, 4); // Split into 4 parts: username, request-type, channel, body
            if (parts.Length < 3)
            {
                // Handle error: message format is incorrect
                return;
            }
            this.Username = parts[0];
            this.RequestType = parts[1];
            this.Channel = parts[2];
            this.Body = parts.Length > 3 ? parts[3] : null;// Body is optional, depending on the request type

        }
    }


}
