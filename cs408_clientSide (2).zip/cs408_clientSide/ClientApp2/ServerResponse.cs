﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server_Side_408
{
    class ServerResponse
    {
        public string ResponseCode { get; set; }
        public string Username { get; set; }
        //200: successful request
        //201: successful subscription
        //202 succesful disconnection
        //400 bad request
        //403 unauthorized
        //500 internal server errror
        public string Channel { get; set; }
        public string Body { get; set; }
        // Constructor that takes a message and parses it
        public ServerResponse(string message)
        {
            string[] parts = message.Split(new char[] { ' ' }, 4); // Split into 4 parts: response-code, username, channel, body

            if (parts.Length < 3)
            {
                // Handle error: message format is incorrect
                return;
            }

            this.ResponseCode = parts[0];
            this.Username = parts[1];
            this.Channel = parts[2];
            this.Body = parts.Length > 3 ? parts[3] : null; // Body is optional, depending on the response
        }

        public override string ToString()
        {
            // Format: <response-code> <username> <channel> <body>
            return $"{ResponseCode} {Username} {Channel} {(Body ?? "N/A")}";
        }

    }
}
